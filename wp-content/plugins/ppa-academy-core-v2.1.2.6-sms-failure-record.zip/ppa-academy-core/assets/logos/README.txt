Brand logos used on the /bkash/ and /nagad/ payment pages and on the checkout.
bkash.jpg  (white logo on bKash pink)   nagad.png  (logo on white)
Replace a file with the same name to change a logo. svg, webp and png/jpg also work for the checkout label.
