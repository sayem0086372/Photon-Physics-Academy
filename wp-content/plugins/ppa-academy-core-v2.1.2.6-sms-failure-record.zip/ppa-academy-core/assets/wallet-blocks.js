(function () {
  var registry = window.wc && window.wc.wcBlocksRegistry;
  var settings = window.wc && window.wc.wcSettings;
  var el = window.wp && window.wp.element;
  if (!registry || !settings || !el) { return; }
  var h = el.createElement;

  function register(name) {
    var data = settings.getSetting(name + '_data', null);
    if (!data) { return; }
    var note = 'After you press Pay Online you will go to the ' + data.title + ' payment page. Send the money there and enter your Transaction ID to place your order.';
    registry.registerPaymentMethod({
      name: name,
      label: h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '8px' } },
        data.logo ? h('img', { src: data.logo, alt: '', style: { maxHeight: '22px', borderRadius: '4px' } }) : null,
        data.title),
      ariaLabel: data.title,
      placeOrderButtonLabel: 'Pay Online',
      content: h('p', { className: 'ppa-wallet-instructions', style: { margin: 0 } }, note),
      edit: h('p', null, note),
      canMakePayment: function () { return true; },
      supports: { features: data.supports || ['products'] }
    });
  }

  register('ppa_bkash');
  register('ppa_nagad');
})();
