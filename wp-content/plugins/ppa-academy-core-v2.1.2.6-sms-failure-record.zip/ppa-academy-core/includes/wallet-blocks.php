<?php
/**
 * bKash / Nagad manual wallet payment for the WooCommerce Cart & Checkout BLOCKS.
 *
 * The classic gateways (PPA_Manual_Wallet_Gateway in store-integration.php) keep
 * doing all order processing. This file only (1) shows them in the block
 * checkout, (2) passes the customer's Transaction ID to the server, and
 * (3) declares block-checkout compatibility.
 */
if (!defined('ABSPATH')) { exit; }

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', dirname(__DIR__) . '/ppa-academy-core.php', true);
    }
});

add_action('woocommerce_blocks_loaded', function () {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) { return; }
    try {
        require_once __DIR__ . '/wallet-blocks-class.php';
    } catch (Throwable $error) {
        error_log('PPA wallet blocks could not load: ' . $error->getMessage());
        return;
    }
    add_action('woocommerce_blocks_payment_method_type_registration', function ($registry) {
        if (!class_exists('PPA_Wallet_Blocks_Method')) { return; }
        $registry->register(new PPA_Wallet_Blocks_Method('ppa_bkash'));
        $registry->register(new PPA_Wallet_Blocks_Method('ppa_nagad'));
    });
});
