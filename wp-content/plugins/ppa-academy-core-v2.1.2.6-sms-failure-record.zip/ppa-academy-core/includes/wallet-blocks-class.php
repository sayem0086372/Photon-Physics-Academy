<?php
/** Loaded only after WooCommerce Blocks is available (see wallet-blocks.php). */
if (!defined('ABSPATH')) { exit; }

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class PPA_Wallet_Blocks_Method extends AbstractPaymentMethodType {
    protected $name = '';

    public function __construct($name) {
        $this->name = $name;
    }

    private function method_key() {
        return $this->name === 'ppa_bkash' ? 'bkash' : 'nagad';
    }

    public function initialize() {}

    public function is_active() {
        return get_option('ppa_store_' . $this->method_key() . '_enabled', 'yes') === 'yes';
    }

    public function get_payment_method_script_handles() {
        if (!wp_script_is('ppa-wallet-blocks', 'registered')) {
            $main = dirname(__DIR__) . '/ppa-academy-core.php';
            $file = dirname(__DIR__) . '/assets/wallet-blocks.js';
            wp_register_script(
                'ppa-wallet-blocks',
                plugins_url('assets/wallet-blocks.js', $main),
                array('wc-blocks-registry', 'wc-settings', 'wp-element'),
                file_exists($file) ? (string) filemtime($file) : '1',
                true
            );
        }
        return array('ppa-wallet-blocks');
    }

    public function get_payment_method_data() {
        $key = $this->method_key();
        $instructions = trim((string) get_option('ppa_store_' . $key . '_instructions', ''));
        if ($instructions === '') {
            $instructions = $key === 'bkash'
                ? 'Open the bKash app or dial *247#, choose Send Money, and send the order total to the number below. Then enter the Transaction ID (TrxID) in the box.'
                : 'Open the Nagad app or dial *167#, choose Send Money, and send the order total to the number below. Then enter the Transaction ID in the box.';
        }
        $logo = '';
        foreach (array('svg', 'png', 'webp', 'jpg') as $ext) {
            if (file_exists(dirname(__DIR__) . '/assets/logos/' . $key . '.' . $ext)) {
                $logo = plugins_url('assets/logos/' . $key . '.' . $ext, dirname(__DIR__) . '/ppa-academy-core.php');
                break;
            }
        }
        return array(
            'logo'         => $logo,
            'accent'       => $key === 'bkash' ? '#e2136e' : '#ef7d00',
            'title'        => $key === 'bkash' ? 'bKash' : 'Nagad',
            'instructions' => $instructions,
            'receiver'     => (string) get_option('ppa_store_receiver', '01312364499'),
            'ussd'         => $key === 'bkash' ? '*247#' : '*167#',
            'supports'     => array('products'),
        );
    }
}
