<?php
/**
 * Full-page bKash / Nagad payment pages:  /bkash/  and  /nagad/
 *
 * Checkout creates the order (pending) and sends the customer here. The customer
 * sees the method's instructions, sends the money, enters the Transaction ID and
 * confirms. The order then becomes on-hold (awaiting manual verification) and the
 * existing "submitted" SMS is sent. Admin verification and the "paid" SMS are unchanged.
 */
if (!defined('ABSPATH')) { exit; }

function ppa_wallet_methods() {
    return array(
        'bkash' => array(
            'key' => 'bkash', 'gateway' => 'ppa_bkash', 'title' => 'bKash', 'ussd' => '*247#',
            'c1' => '#e2136e', 'c2' => '#e2136e', 'soft' => '#fdf0f6', 'logo' => 'bkash.jpg', 'logo_card' => false,
        ),
        'nagad' => array(
            'key' => 'nagad', 'gateway' => 'ppa_nagad', 'title' => 'Nagad', 'ussd' => '*167#',
            'c1' => '#ed1c24', 'c2' => '#f7941d', 'soft' => '#fff4ec', 'logo' => 'nagad.png', 'logo_card' => true,
        ),
    );
}

function ppa_wallet_default_steps($cfg, $receiver) {
    return array(
        'Open the ' . $cfg['title'] . ' App or dial ' . $cfg['ussd'] . '.',
        'Select Send Money.',
        'Enter the payment number: ' . $receiver . '.',
        'Enter the exact order amount.',
        'Confirm the payment.',
        'Copy the Transaction ID (TrxID) from the confirmation message.',
    );
}

function ppa_wallet_submit_steps() {
    return array(
        'Paste your Transaction ID (TrxID) into the Transaction ID box below.',
        'Click Place Order to submit your order.',
    );
}

function ppa_wallet_important_notes() {
    return array(
        'Make sure the payment amount matches your order total.',
        'Enter the correct Transaction ID.',
        'Your order will remain pending until our team verifies the payment.',
        'Never share your PIN or OTP with anyone.',
    );
}

function ppa_wallet_tx_used_elsewhere($tx, $order_id) {
    try {
        $ids = wc_get_orders(array(
            'limit' => 1, 'return' => 'ids', 'exclude' => array((int) $order_id),
            'meta_key' => '_ppa_wallet_transaction_id', 'meta_value' => $tx,
            'status' => array_keys(wc_get_order_statuses()),
        ));
        return !empty($ids);
    } catch (Throwable $error) {
        return false;
    }
}

add_action('template_redirect', 'ppa_wallet_maybe_render_page', 1);
function ppa_wallet_maybe_render_page() {
    if (is_admin()) { return; }
    $uri  = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
    $path = trim((string) parse_url($uri, PHP_URL_PATH), '/');
    $home = trim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
    foreach (ppa_wallet_methods() as $key => $cfg) {
        if (strcasecmp($path, trim($home . '/' . $key, '/')) === 0) {
            ppa_wallet_render_page($cfg);
            exit;
        }
    }
}

function ppa_wallet_render_page($cfg) {
    if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow');
    header('Content-Type: text/html; charset=utf-8');
    status_header(200);

    if (!function_exists('wc_get_order')) {
        ppa_wallet_print_message($cfg, 'Payment page unavailable', 'The store is not available right now. Please try again later.');
        return;
    }

    $source   = (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') ? $_POST : $_GET;
    $order_id = isset($source['order']) ? absint($source['order']) : 0;
    $key      = isset($source['key']) ? sanitize_text_field(wp_unslash((string) $source['key'])) : '';
    $order    = $order_id ? wc_get_order($order_id) : false;

    $valid = $order && $key !== '' && hash_equals((string) $order->get_order_key(), $key) && $order->get_payment_method() === $cfg['gateway'];
    if (!$valid) {
        ppa_wallet_print_message($cfg, 'Payment link not valid', 'This payment link is not valid or has expired. Please go back to the store and place your order again.');
        return;
    }
    if ($order->is_paid() || in_array($order->get_status(), array('processing', 'completed'), true)) {
        wp_safe_redirect($order->get_checkout_order_received_url());
        exit;
    }
    if (in_array($order->get_status(), array('cancelled', 'refunded'), true)) {
        ppa_wallet_print_message($cfg, 'Order cancelled', 'This order was cancelled. Please go back to the store and place a new order.');
        return;
    }

    $error = '';
    $typed = '';
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ppa_wallet_nonce'])) {
        $nonce = sanitize_text_field(wp_unslash((string) $_POST['ppa_wallet_nonce']));
        $raw   = isset($_POST['ppa_wallet_transaction_id']) ? sanitize_text_field(wp_unslash((string) $_POST['ppa_wallet_transaction_id'])) : '';
        $typed = $raw;
        $tx    = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $raw));
        if (!wp_verify_nonce($nonce, 'ppa_wallet_pay_' . $order->get_id())) {
            $error = 'This page expired. Please try again.';
        } elseif (strlen($tx) < 6 || strlen($tx) > 30) {
            $error = 'Please enter a valid Transaction ID. It is in the confirmation SMS you received after sending the money.';
        } elseif (ppa_wallet_tx_used_elsewhere($tx, $order->get_id())) {
            $error = 'This Transaction ID has already been used for another order. Please check it and try again.';
        } else {
            $order->update_meta_data('_ppa_wallet_transaction_id', $tx);
            $order->update_meta_data('_ppa_payment_verified', 'no');
            $order->add_order_note('Customer submitted ' . $cfg['title'] . ' Transaction ID ' . $tx . '. Awaiting manual verification.');
            if ($order->get_status() !== 'on-hold') {
                $order->update_status('on-hold', 'Awaiting manual mobile wallet payment verification.');
                wc_reduce_stock_levels($order->get_id());
            } else {
                $order->save();
            }
            if (function_exists('WC') && WC()->cart) { WC()->cart->empty_cart(); }
            wp_safe_redirect($order->get_checkout_order_received_url());
            exit;
        }
    }

    ppa_wallet_print_payment($cfg, $order, $key, $error, $typed);
}

function ppa_wallet_logo_url($cfg) {
    return plugins_url('assets/logos/' . $cfg['logo'], dirname(__DIR__) . '/ppa-academy-core.php');
}

function ppa_wallet_page_open($cfg, $title) {
    $icon = function_exists('get_site_icon_url') ? get_site_icon_url(64) : '';
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html($title . ' - Photon Physics Academy'); ?></title>
<?php if ($icon) : ?><link rel="icon" href="<?php echo esc_url($icon); ?>"><?php endif; ?>
<style>
:root{--c1:<?php echo esc_html($cfg['c1']); ?>;--c2:<?php echo esc_html($cfg['c2']); ?>;--soft:<?php echo esc_html($cfg['soft']); ?>}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Noto Sans Bengali","Hind Siliguri",Arial,sans-serif;background:var(--soft);color:#1f2937;line-height:1.5}
.hero{background:linear-gradient(135deg,var(--c1),var(--c2));padding:24px 16px 72px;text-align:center}
.hero .wide{display:block;margin:0 auto;max-width:240px;width:70%;height:auto}
.hero .card-logo{display:inline-block;background:#fff;border-radius:22px;padding:10px;box-shadow:0 8px 22px rgba(0,0,0,.18)}
.hero .card-logo img{display:block;width:96px;height:96px}
.wrap{max-width:480px;margin:-50px auto 32px;padding:0 14px}
.card{background:#fff;border-radius:18px;padding:22px 20px;box-shadow:0 10px 30px rgba(15,23,42,.12)}
h1{font-size:22px;margin:0 0 4px}
.meta{color:#64748b;font-size:14px;margin:0 0 14px}
.amount{display:flex;justify-content:space-between;align-items:center;gap:10px;background:var(--soft);border-radius:12px;padding:12px 14px;margin:0 0 16px}
.amount span{color:#475569;font-size:14px}
.amount strong{font-size:26px;color:var(--c1)}
ol.steps{margin:0 0 16px;padding-left:22px}
ol.steps li{margin:0 0 8px}
.num{display:flex;align-items:center;justify-content:space-between;gap:10px;border:2px dashed var(--c1);border-radius:12px;padding:12px 14px;margin:0 0 18px}
.num small{display:block;color:#64748b}
.num strong{font-size:22px;letter-spacing:.03em}
.copy{border:2px solid var(--c1);background:#fff;color:var(--c1);border-radius:10px;padding:8px 14px;font-weight:700;cursor:pointer}
label{display:block;font-weight:700;margin:0 0 6px}
input[type=text]{width:100%;padding:14px;border:2px solid #e2e8f0;border-radius:12px;font-size:18px;letter-spacing:.04em;text-transform:uppercase}
input[type=text]:focus{outline:none;border-color:var(--c1)}
.err{color:#b91c1c;background:#fef2f2;border-radius:10px;padding:10px 12px;margin:10px 0 0;font-size:14px}
.btn{display:block;width:100%;margin-top:14px;padding:15px;border:0;border-radius:12px;background:linear-gradient(135deg,var(--c1),var(--c2));color:#fff;font-size:17px;font-weight:700;cursor:pointer}
.note{color:#64748b;font-size:13px;text-align:center;margin:14px 0 0}
.back{display:block;text-align:center;margin-top:16px;color:#475569;font-size:14px}
.sec{font-size:16px;margin:0 0 8px;color:var(--c1)}
.imp{background:var(--soft);border-radius:12px;padding:12px 14px;margin:16px 0 0;font-size:14px}
.imp strong{display:block;margin:0 0 6px}
.imp ul{margin:0;padding-left:20px}
.imp li{margin:0 0 4px}
.foot{text-align:center;color:#64748b;font-size:12px;padding:0 0 24px}
</style>
</head>
<body>
<div class="hero">
<?php if (!empty($cfg['logo_card'])) : ?>
<span class="card-logo"><img src="<?php echo esc_url(ppa_wallet_logo_url($cfg)); ?>" alt="<?php echo esc_attr($cfg['title']); ?>"></span>
<?php else : ?>
<img class="wide" src="<?php echo esc_url(ppa_wallet_logo_url($cfg)); ?>" alt="<?php echo esc_attr($cfg['title']); ?>">
<?php endif; ?>
</div>
<div class="wrap"><div class="card">
<?php
}

function ppa_wallet_page_close() {
    ?></div>
<a class="back" href="<?php echo esc_url(function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/')); ?>">&larr; Back to cart</a>
</div>
<div class="foot">Photon Physics Academy, Mymensingh</div>
</body>
</html>
<?php
}

function ppa_wallet_print_message($cfg, $title, $text) {
    ppa_wallet_page_open($cfg, $title);
    ?><h1><?php echo esc_html($title); ?></h1>
<p class="meta" style="margin:8px 0 0"><?php echo esc_html($text); ?></p>
<?php
    ppa_wallet_page_close();
}

function ppa_wallet_print_payment($cfg, $order, $key, $error, $typed) {
    $slug     = $cfg['key'];
    $receiver = (string) get_option('ppa_store_receiver', '01312364499');
    $raw      = trim((string) get_option('ppa_store_' . $slug . '_instructions', ''));
    $steps    = array();
    foreach (preg_split('/\r?\n/', $raw) as $line) {
        $line = trim(preg_replace('/^\s*\d+\s*[\.\)\-:]\s*/', '', $line));
        if ($line !== '') { $steps[] = $line; }
    }
    if (!$steps) { $steps = ppa_wallet_default_steps($cfg, $receiver); }
    $amount   = html_entity_decode(wp_strip_all_tags($order->get_formatted_order_total()), ENT_QUOTES, 'UTF-8');

    ppa_wallet_page_open($cfg, 'Pay with ' . $cfg['title']);
    ?><h1>Pay with <?php echo esc_html($cfg['title']); ?></h1>
<p class="meta">Order #<?php echo esc_html($order->get_order_number()); ?></p>
<div class="amount"><span>Amount to send</span><strong><?php echo esc_html($amount); ?></strong></div>
<div class="num"><div><small>Payment number</small><strong id="ppa-num"><?php echo esc_html($receiver); ?></strong></div><button type="button" class="copy" id="ppa-copy">Copy</button></div>
<h2 class="sec">How to pay</h2>
<ol class="steps">
<?php foreach ($steps as $step) : ?>
<li><?php echo esc_html($step); ?></li>
<?php endforeach; ?>
</ol>
<h2 class="sec">Submit your order</h2>
<ol class="steps">
<?php foreach (ppa_wallet_submit_steps() as $step) : ?>
<li><?php echo esc_html($step); ?></li>
<?php endforeach; ?>
</ol>
<form method="post" action="<?php echo esc_url(home_url('/' . $slug . '/')); ?>" autocomplete="off">
<input type="hidden" name="order" value="<?php echo esc_attr($order->get_id()); ?>">
<input type="hidden" name="key" value="<?php echo esc_attr($key); ?>">
<input type="hidden" name="ppa_wallet_nonce" value="<?php echo esc_attr(wp_create_nonce('ppa_wallet_pay_' . $order->get_id())); ?>">
<label for="ppa-tx">Transaction ID</label>
<input id="ppa-tx" name="ppa_wallet_transaction_id" type="text" required autocomplete="off" autocapitalize="characters" placeholder="e.g. 8N7A6D5EE3" value="<?php echo esc_attr($typed); ?>">
<?php if ($error !== '') : ?><div class="err" role="alert"><?php echo esc_html($error); ?></div><?php endif; ?>
<button class="btn" type="submit">Place order</button>
</form>
<div class="imp"><strong>Important</strong><ul>
<?php foreach (ppa_wallet_important_notes() as $note) : ?>
<li><?php echo esc_html($note); ?></li>
<?php endforeach; ?>
</ul></div>
<p class="note">You will receive an SMS after you place your order.</p>
<script>
(function(){var b=document.getElementById('ppa-copy'),n=document.getElementById('ppa-num');if(!b||!n){return;}
b.addEventListener('click',function(){var t=n.textContent;
function done(){b.textContent='Copied';}
if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){});}
else{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');done();}catch(e){}document.body.removeChild(a);}
});})();
</script>
<?php
    ppa_wallet_page_close();
}
